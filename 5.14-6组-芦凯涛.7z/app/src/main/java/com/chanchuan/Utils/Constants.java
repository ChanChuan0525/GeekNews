package com.chanchuan.Utils;

import java.util.ArrayList;
import java.util.List;

public class Constants {
    public static List<String> title = new ArrayList<>();
    public static List<Boolean> isSelected = new ArrayList<>();
}
