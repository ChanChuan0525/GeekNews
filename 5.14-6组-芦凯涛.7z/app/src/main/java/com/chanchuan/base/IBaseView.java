package com.chanchuan.base;

public interface IBaseView {
    void error(String errorMsg);
}
